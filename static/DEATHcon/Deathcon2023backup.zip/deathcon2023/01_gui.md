# Lab: GUI mode walk through

# **Objective**

This lab is a guided walk-through for running Velociraptor in GUI mode. 

GUI mode will be used throughout the workshop.

We also walk through importing additional content into Velociraptor.

The Velociraptor GUI is configured to open automatically upon boot, but the credentials are available below:

- URL: [`https://127.0.0.1:8889/`](https://127.0.0.1:8889/)
- Username: `admin`
- Password: `password`

# **Dependencies**

Windows 10+ VM with administrator level access.

- UEFI enabled for UEFI use cases (detail later)

Internet access if you would like to do content import.

# Tasks

### Download and run Velociraptor in GUI mode

1. Download latest velociraptor release
    
    0.7.0-3 at time of writing.
    
    [https://github.com/Velocidex/velociraptor/releases](https://github.com/Velocidex/velociraptor/releases)
    

![Untitled](Untitled.png)

Please copy the downloaded exe to the desktop and rename to velociraptor.exe

1. Open cmd.exe as administrator and cd to your desktop. Run `velociraptor.exe -h` to scope options via help

![Untitled](Untitled%201.png)

Many velociraptor features are available via the cli and at any level you can view help to understand what switches are available. 

As we are running GUI mode run: `velociraptor.exe gui -h`

![Untitled](Untitled%202.png)

By default Velociraptor will use a datastore in the temp folder. This may not be desired as the OS may purge temp folders and we may loose our work. We can use the datastore switch to specify a path.

1. Create VRdata folder and run Velociraptor

`mkdir VRdata`

`velociraptor.exe gui --datastore=./VRdata -v`

![Untitled](Untitled%203.png)

Running -v enables us to review verbose mode in Stdout. Take a moment to scroll up through the output to see what the velociraptor gui mode is doing. 

By default a web browser will also load and automatically log into the local velociraptor instance.

NOTE: In windows 11 this feature was not working with Edge only default installs and manual load is required.

Open a browser and goto: 

- URL: [`https://127.0.0.1:8889/`](https://127.0.0.1:8889/)
- Username: `admin`
- Password: `password`

![Untitled](Untitled%204.png)

1. Explore GUI and follow demo.

Ensure you familiarise yourself with items important for detection development.

- VFS
- Collection
- Artifacts
- Notebook

### Import additional content

1. Open server collection view and run Server.Import.ArtifactExchange 

![Untitled](Untitled%205.png)

![Untitled](Untitled%206.png)

We can configure a prefix to add to each imported artifact, but in this case we will keep as default.

![Untitled](Untitled%207.png)

When imported you can see all artifacts have this prefix.

![Untitled](Untitled%208.png)

You should now have several Exchange prefixed artifacts in your artifact view.

![Untitled](Untitled%209.png)

We will use several of these artifacts later 🙂

1. Run the same import process for **Exchange.Server.Import.DetectRaptor**

![Untitled](Untitled%2010.png)

![Untitled](Untitled%2011.png)

👈 To go back, tap the link at the top left, or swipe from left to right across your screen.