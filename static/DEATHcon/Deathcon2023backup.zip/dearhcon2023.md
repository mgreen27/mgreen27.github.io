# Velociraptor DEATHcon 2023

Landing page for Velociraptor DEATHcon workshop.

Watch the video and / or walk through the lab descriptions - feel free to ask any questions!

Background: [video link](https://youtu.be/i_HgfOCgFMw)

[Lab: GUI mode walk through](01_gui/)

VQL / Accessors: [video link](https://youtu.be/p8SHRIDO5h0)

[Lab: VQL / Accessors](Lab%20VQL%20Accessors)

VQL Performance and Yara: [video link](https://youtu.be/OcA1ihRttSE)

[Lab: VQL yara performance](Lab%20VQL%20yara%20performance)

Patched RDP: [video link](https://youtu.be/NFQ8I7uZ-ec)

[Lab: Patched RDP](Lab%20Patched%20RDP)

UEFI BlackLotus: [video link](https://youtu.be/iqYYVuz_BSM)

[Lab: UEFI Black Lotus](Lab%20UEFI%20Black%20Lotus)

[Lab: LNK analysis](Lab%20LNK%20analysis)

### Links

- [Velociraptor Github](https://github.com/Velocidex/velociraptor)
- [Velociraptor Documentation site](https://docs.velociraptor.app/)
- [Velociraptor Discord](https://docs.velociraptor.app/discord/)